package com.micro.services.microservice;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;


@RestController
@EnableAutoConfiguration
public class App 
{
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	 @RequestMapping("/listusers")
	    String home(HttpServletRequest request,HttpServletResponse response) throws IOException, SQLException, ClassNotFoundException  {
		 System.out.println("Test action get called..");
		 
		 Connection con =OracleConnection.getConnection();
		 Statement selectStmt = con.createStatement();
		 
			ResultSet rs = selectStmt
			    .executeQuery("SELECT * from user");
			ArrayList<User> userlist=new ArrayList<User>();
			while(rs.next())
			{
				User user1= new User();
				user1.setId(Integer.parseInt(rs.getString(1)));
				user1.setUserName(rs.getString(2));
				user1.setAddress(rs.getString(3));
				user1.setEmail(rs.getString(4));
				userlist.add(user1);
			    System.out.println(rs.getString(1));    //First Column
			    System.out.println(rs.getString(2));    //Second Column
			    System.out.println(rs.getString(3));    //Third Column
			    System.out.println(rs.getString(4));    //Fourth Column
			}
			Gson gson = new Gson();
			JsonObject jsonObject = new JsonObject();
			JsonElement element = gson.toJsonTree(userlist);
			jsonObject.addProperty("success", true);
			jsonObject.add("UserList", element);
			PrintWriter out = response.getWriter();
			out.println(jsonObject.toString());
			out.close();
			
			
	        return "Hello World test...!";
	    }
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	 @RequestMapping(value = "/name", method = RequestMethod.POST)
	 @ResponseBody
	 
	    public ResponseEntity<User> saveName(@RequestBody User user) throws ClassNotFoundException, SQLException {
		 System.out.println("save name call..");
		 	Connection con = null;
			Statement stmt = null;
			con=OracleConnection.getConnection();
			stmt = con.createStatement();
		    try {
				String sql = "INSERT INTO user " +
				               " (user_name,address,email)  VALUES ('"+user.getFirstName()+"', '"+user.getAddress()+"', '"+user.getEmail()+"')";
				stmt.executeUpdate(sql);
				System.out.println("Data inseted successfully..");
				
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		    
		 return new ResponseEntity<User>(user, HttpStatus.OK);
	 }
	@CrossOrigin(origins = "*", allowedHeaders = "*")
	 @RequestMapping(value = "/ajaxRegister", method = RequestMethod.POST)
	 @ResponseBody
		public String ajaxRegister(@Validated User user, Model model,HttpServletRequest request,HttpServletResponse response) throws IOException {
		 response.setHeader("Content-Type", "json");
		 	Gson gson = new Gson();
			JsonObject jsonObject = new JsonObject();
			JsonElement element = gson.toJsonTree(user);
			jsonObject.addProperty("success", true);
			jsonObject.add("User", element);
			PrintWriter out = response.getWriter();
			out.println(jsonObject.toString());
			out.close();
		 return null;
	 }
    public static void main( String[] args )
    {
        SpringApplication.run(App.class, args);
    }
}

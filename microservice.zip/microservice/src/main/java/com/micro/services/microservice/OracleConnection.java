package com.micro.services.microservice;





import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class OracleConnection {
	
	static Connection con=null;
	/*public static void main(String[] args) throws ClassNotFoundException{
		
		Class.forName("oracle.jdbc.driver.OracleDriver");  
		  
		//step2 create  the connection object  
		try {
			Connection con=DriverManager.getConnection(  
			"jdbc:oracle:thin:@database-1.cnsmoucgrpad.ap-south-1.rds.amazonaws.com:1521:ORCL","admin123","rootuser");
			System.out.println("connection successful");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally{
			con.clo
		}
	}*/
	
	static public Connection getConnection() throws ClassNotFoundException {
		
		try {
			/*Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@database-1.cnsmoucgrpad.ap-south-1.rds.amazonaws.com:1521:ORCL","admin123","rootuser");*/
			
			Class.forName("com.mysql.jdbc.Driver");  
			con=DriverManager.getConnection("jdbc:mysql://database-2.cnsmoucgrpad.ap-south-1.rds.amazonaws.com:3306/testdb","admin","admin123"); 
			
			return con;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return con;
	}
	
	static public void closeConnection(){
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

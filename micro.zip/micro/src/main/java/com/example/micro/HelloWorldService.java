package com.example.micro;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldService {
	
	@RequestMapping("/test")
	public String test() {
		System.out.println("springbott started..");
		return "Hello World!";
	}

}

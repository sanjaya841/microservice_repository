package com.twilio.twiliotest;


import  static spark.Spark.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.twilio.twiml.MessagingResponse;
import com.twilio.twiml.messaging.Body;
import com.twilio.twiml.messaging.Message;

public class ReceiveSms {

	public static void main(String[] args) {
		// TODO Auto-generated method stub rmdir /s "C:\Users\karim\Desktop\My Dumps"
		   
		        get("/", (req, res) -> "Hello Web");

		        post("/sms", (req, res) -> {
		        	
		        	Object o=req.body();
		        	String str2=o.toString();
		        	
		        		String[] arrSplit = str2.split("&");
		        	String incomingmsg="";
		        	if(arrSplit.length>1){
			        	incomingmsg=arrSplit[4];
			        	incomingmsg=incomingmsg.replaceAll("Body=", "");
			        	incomingmsg=incomingmsg.replaceAll("\\+", " ");
			        	 System.out.println(incomingmsg);
			        	 if(incomingmsg.equals("BNKPA67N")){
			        		 incomingmsg="ICICI CPCS Results : No match found Customer eligible for loan :: "+incomingmsg;
			        	 }else if(incomingmsg.contains("balance") || incomingmsg.equalsIgnoreCase("BALANCE") ){
			        		 incomingmsg="ICICI WhatsApp service -->Your  balance is 500000 Rs.Thanku...";
			        	 }
			        	 else{
			        	 incomingmsg="ICICI CPCS Results :Match found Customer in default list  ::"+incomingmsg;
			        	 }
			        	 res.type("application/xml");
			        	 //res.type("application/json");

				            Body body = new Body
				                    .Builder(incomingmsg)
				                    .build();
				            Message sms = new Message
				                    .Builder()
				                    .body(body)
				                    .build();
				            MessagingResponse twiml = new MessagingResponse
				                    .Builder()
				                    .message(sms)
				                    .build();
				            return twiml.toXml();
		        	}else{
		        		String [] postmanReq=str2.split(":");
		        		String pan=postmanReq[1];
		        		pan=pan.replace("}", "");
		        		//response.setHeader("Content-Type", "json");
		        		User user = new User();
		        		user.setFirstName("Sanjay");
		        		user.setLastName("Ambade");
		        		user.setPan(pan);
		        		user.setCpcsResults("ICICI CPCS Results : No match found Customer eligible for loan.");
		        		Gson gson = new Gson();
		        		JsonObject jsonObject = new JsonObject();
		        		JsonElement element = gson.toJsonTree(user);
		        		jsonObject.add("User", element);
		        		PrintWriter out = res.raw().getWriter();
		        		out.println(jsonObject.toString());
		        		out.close();
		        		res.type("application/json");
		        		return null;
		        	}
		        	 //incomingmsg="Your balnce is 1000 core rs enjoy my love";
		        	
		            
		        });
		    
		


	}

}

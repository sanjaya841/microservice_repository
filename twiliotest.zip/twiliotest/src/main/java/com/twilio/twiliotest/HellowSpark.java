package com.twilio.twiliotest;

import static spark.Spark.*;
public class HellowSpark {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		get("/list", (req, res) -> "Hello, World!");

	}

}

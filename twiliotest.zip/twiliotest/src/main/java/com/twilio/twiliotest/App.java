package com.twilio.twiliotest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

/**
 * Hello world!
 *
 */
public class App 
{
	// Find your Account Sid and Auth Token at twilio.com/console
	 public static final String ACCOUNT_SID =
	         "ACe456dae0b7b44d0aa43da0a93f0bf794";
	 public static final String AUTH_TOKEN =
	         "a6883fab35b7d7c48b74463c5d5d5f48";
	 
	 private static File configFile = new File("D:/Hardik/smtp.properties");
	 private static Properties configProps =new Properties();
	 public static void main(String[] args) throws FileNotFoundException {
		 
		 try {
			 String sms="";
			if (configFile.exists()) {
			     InputStream inputStream = new FileInputStream(configFile);
			     configProps.load(inputStream);
			     inputStream.close();
			 }
			 String name=configProps.getProperty("name");
			 String usermobileno=configProps.getProperty("usermobileno");
			 String subject=configProps.getProperty("subject");
			 String course=configProps.getProperty("course");
			 
			 sms=name+" register on your site for subject:: "+subject+" course:: "+course+" and his mobile no is:: "+usermobileno;
			 
			 Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

			 Message message = Message
			         .creator(new PhoneNumber(configProps.getProperty("toMobileNo")), // to
			                 new PhoneNumber(configProps.getProperty("fromMobileNo")), // from
			        		 //new PhoneNumber("whatsapp:+15105607755"), // from
			                 sms)
			         .create();

			 System.out.println(message.getSid());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 }
}

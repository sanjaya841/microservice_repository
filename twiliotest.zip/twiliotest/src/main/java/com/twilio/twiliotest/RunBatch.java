package com.twilio.twiliotest;
import java.io.File;
import java.io.IOException;

public class RunBatch {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		try {
			
			ProcessBuilder pb = new ProcessBuilder("cmd", "/c", "testbatch.bat");
			File dir = new File("E:/Develoment_Softwares");
			pb.directory(dir);
			Process p = pb.start();
			System.out.println("success");
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
